/* =========================================================================
   PortalDive — single-canvas renderer for the "chevron → hyperspace" dive.
   One deterministic timeline drives every layer, so the live preview and the
   baked WebM are pixel-identical. Render with:
       PortalDive.render(ctx, W, H, p)     // p = dive progress 0..1
   after PortalDive.setImage(img).
   ========================================================================= */
(function (global) {
  "use strict";

  var WEDGES = 6;

  /* ---- easing ---- */
  function clamp(v, a, b) { return v < a ? a : v > b ? b : v; }
  function smoothstep(e0, e1, x) { x = clamp((x - e0) / (e1 - e0), 0, 1); return x * x * (3 - 2 * x); }
  function easeInOutCubic(t) { return t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2; }
  function easeInPow(t, k) { return Math.pow(clamp(t, 0, 1), k); }
  function easeOutCubic(t) { return 1 - Math.pow(1 - clamp(t, 0, 1), 3); }

  /* ---- seeded star field (stable across renders & the bake) ---- */
  var stars = null;
  var SCOLS = ['rgba(255,255,255,', 'rgba(206,228,255,', 'rgba(140,238,224,',
               'rgba(255,206,156,', 'rgba(168,184,255,'];
  function buildStars() {
    var seed = 1337;
    function rnd() { seed = (seed * 1664525 + 1013904223) & 0x7fffffff; return seed / 0x7fffffff; }
    stars = [];
    for (var i = 0; i < 300; i++) {
      stars.push({
        a: rnd() * Math.PI * 2,
        r0: rnd() * 30 + 4,
        spd: 0.35 + rnd() * 1.25,
        col: SCOLS[(rnd() * SCOLS.length) | 0],
        twk: rnd()
      });
    }
  }

  var IMG = null;
  function setImage(img) { IMG = img; if (!stars) buildStars(); }

  function wedgeAngle(i) { return -90 + i * (360 / WEDGES); }

  /* ---- the dive timeline, expressed as a function of p (0..1) ---- */
  function frame(p) {
    p = clamp(p, 0, 1);

    // anticipation: a small inward "load" that peaks ~p=0.1 then releases
    var antic = p < 0.22 ? Math.sin(Math.PI * (p / 0.22)) : 0;        // 0→1→0
    var release = easeInPow(smoothstep(0.12, 1, p), 2.35);            // accelerating burst

    return {
      // group rotation — heavy door: slow start, accelerate, arrive
      rotor: (Math.PI / 2) * easeInOutCubic(clamp(p / 0.95, 0, 1)),
      // separation along each wedge's radial axis (in box-fractions)
      sepFrac: -0.055 * antic + 1.15 * release,
      // shard scale (slight squash during the load, then expands as it flies out)
      scale: 1 - 0.05 * antic + 1.65 * easeInPow(release, 1.05),
      // a touch of spin on each shard as it tumbles away
      spin: (8 * Math.PI / 180) * easeInPow(p, 1.6),
      // shards stay solid through the opening, then dissolve into the light
      alpha: 1 - smoothstep(0.5, 0.9, p),
      // extra glow on the shard faces as they catch the core light
      bloom: smoothstep(0.18, 0.62, p) * (1 - smoothstep(0.7, 0.95, p)),
      // seam darkening grows as the pieces part
      seam: seamAt(p),
      // core flare
      core: coreAt(p),
      // ambient halo fades as the door opens
      halo: (0.6) * (1 - smoothstep(0.05, 0.5, p)),
      // hyperspace + final blackout
      hyper: clamp((p - 0.09) / 0.74, 0, 1),
      black: smoothstep(0.80, 1.0, p)
    };
  }

  // seam params interpolated across keyframes (matches the original CSS feel)
  function seamAt(p) {
    var ks = [
      [0.00, 0, 0, 0, 0],
      [0.09, 2, 0.16, 5, 0.08],
      [0.45, 12, 0.46, 20, 0.26],
      [1.00, 23, 0.72, 34, 0.40]
    ];
    for (var i = 1; i < ks.length; i++) {
      if (p <= ks[i][0]) {
        var a = ks[i - 1], b = ks[i];
        var u = (p - a[0]) / (b[0] - a[0]);
        return {
          w: a[1] + (b[1] - a[1]) * u,
          d: a[2] + (b[2] - a[2]) * u,
          r: a[3] + (b[3] - a[3]) * u,
          ad: a[4] + (b[4] - a[4]) * u
        };
      }
    }
    var L = ks[ks.length - 1];
    return { w: L[1], d: L[2], r: L[3], ad: L[4] };
  }

  // core flare opacity + scale across keyframes
  function coreAt(p) {
    var op = [[0, 0], [0.2, 0.8], [0.6, 1], [1, 0]];
    var sc = [[0, 0.5], [0.2, 1.1], [0.6, 2.8], [1, 6.5]];
    function lerp(ks) {
      for (var i = 1; i < ks.length; i++) {
        if (p <= ks[i][0]) {
          var a = ks[i - 1], b = ks[i], u = (p - a[0]) / (b[0] - a[0]);
          // ease the core a touch for a softer bloom
          u = u * u * (3 - 2 * u);
          return a[1] + (b[1] - a[1]) * u;
        }
      }
      return ks[ks.length - 1][1];
    }
    return { op: lerp(op), sc: lerp(sc) };
  }

  /* ---- shard clip: pie slice ∩ circle, in local (pre-transform) coords ---- */
  function clipShard(ctx, cdeg, R) {
    var half = 30, ov = 0.6, RR = R * 4.5;
    var a1 = (cdeg - half - ov) * Math.PI / 180;
    var a2 = (cdeg + half + ov) * Math.PI / 180;
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.lineTo(Math.cos(a1) * RR, Math.sin(a1) * RR);
    ctx.lineTo(Math.cos(a2) * RR, Math.sin(a2) * RR);
    ctx.closePath();
    ctx.clip();
    ctx.beginPath();
    ctx.arc(0, 0, R, 0, Math.PI * 2);
    ctx.clip();
  }

  /* ---- main render ---- */
  function render(ctx, W, H, p) {
    var f = frame(p);
    var cx = W / 2, cy = H / 2;
    var box = H * 0.62;               // portal box edge
    var R = box * 0.494;              // circular crop radius
    var sepPx = f.sepFrac * box;

    // background
    var bg = ctx.createRadialGradient(cx, cy * 0.92, 0, cx, cy, Math.max(W, H) * 0.75);
    bg.addColorStop(0, '#0d1322');
    bg.addColorStop(0.55, '#070a12');
    bg.addColorStop(1, '#04060c');
    ctx.fillStyle = bg;
    ctx.fillRect(0, 0, W, H);

    // ambient halo
    if (f.halo > 0.001) {
      ctx.save();
      ctx.globalCompositeOperation = 'lighter';
      var hg = ctx.createRadialGradient(cx, cy, 0, cx, cy, box * 0.78);
      hg.addColorStop(0.30, 'rgba(255,170,90,' + (0.33 * f.halo) + ')');
      hg.addColorStop(0.58, 'rgba(60,110,200,' + (0.20 * f.halo) + ')');
      hg.addColorStop(0.72, 'rgba(60,110,200,0)');
      ctx.fillStyle = hg;
      ctx.fillRect(0, 0, W, H);
      ctx.restore();
    }

    // image cover-mapping (portal.jpg centered into the box)
    var iw = IMG ? IMG.naturalWidth || IMG.width : 1024;
    var ih = IMG ? IMG.naturalHeight || IMG.height : 768;
    var cover = box / Math.min(iw, ih);
    var dw = iw * cover, dh = ih * cover;

    // the six shards
    if (f.alpha > 0.001 && IMG) {
      for (var i = 0; i < WEDGES; i++) {
        var cdeg = wedgeAngle(i);
        var ang = cdeg * Math.PI / 180;
        var ux = Math.cos(ang), uy = Math.sin(ang);

        ctx.save();
        ctx.translate(cx, cy);
        ctx.rotate(f.rotor);                       // group rotation
        ctx.translate(ux * sepPx, uy * sepPx);     // fly outward
        ctx.scale(f.scale, f.scale);
        ctx.rotate(f.spin * (i % 2 ? 1 : -1) * 0.5 + f.spin); // gentle tumble
        ctx.globalAlpha = f.alpha;

        clipShard(ctx, cdeg, R);
        ctx.drawImage(IMG, -dw / 2, -dh / 2, dw, dh);

        // seam darkening (apex radial + edge conic)
        if (f.seam.d > 0.002) {
          var s = f.seam;
          if (s.ad > 0.002) {
            var ag = ctx.createRadialGradient(0, 0, 0, 0, 0, R * (s.r / 100));
            ag.addColorStop(0, 'rgba(3,5,12,' + s.ad + ')');
            ag.addColorStop(1, 'rgba(3,5,12,0)');
            ctx.fillStyle = ag;
            ctx.fillRect(-R, -R, R * 2, R * 2);
          }
          if (typeof ctx.createConicGradient === 'function') {
            var cg = ctx.createConicGradient((cdeg - 30) * Math.PI / 180, 0, 0);
            cg.addColorStop(0, 'rgba(3,5,12,' + s.d + ')');
            cg.addColorStop(clamp(s.w / 360, 0, 0.5), 'rgba(3,5,12,0)');
            cg.addColorStop(clamp((60 - s.w) / 360, 0, 0.5), 'rgba(3,5,12,0)');
            cg.addColorStop(60 / 360, 'rgba(3,5,12,' + s.d + ')');
            cg.addColorStop(1, 'rgba(3,5,12,' + s.d + ')');
            ctx.fillStyle = cg;
            ctx.fillRect(-R, -R, R * 2, R * 2);
          }
        }

        // bloom — light catching the shard faces
        if (f.bloom > 0.01) {
          ctx.globalCompositeOperation = 'lighter';
          ctx.globalAlpha = f.alpha * f.bloom * 0.5;
          var bgg = ctx.createRadialGradient(0, 0, 0, 0, 0, R);
          bgg.addColorStop(0, 'rgba(255,228,196,0.9)');
          bgg.addColorStop(0.5, 'rgba(255,170,110,0.25)');
          bgg.addColorStop(1, 'rgba(255,170,110,0)');
          ctx.fillStyle = bgg;
          ctx.fillRect(-R, -R, R * 2, R * 2);
        }
        ctx.restore();
      }
    }

    // core flare
    if (f.core.op > 0.002) {
      ctx.save();
      ctx.globalCompositeOperation = 'screen';
      ctx.globalAlpha = f.core.op;
      var cr = (box * 0.17) * f.core.sc;
      var cgr = ctx.createRadialGradient(cx, cy, 0, cx, cy, cr);
      cgr.addColorStop(0, 'rgba(255,248,236,1)');
      cgr.addColorStop(0.22, 'rgba(255,206,149,0.95)');
      cgr.addColorStop(0.45, 'rgba(255,154,90,0.5)');
      cgr.addColorStop(0.68, 'rgba(90,110,220,0.25)');
      cgr.addColorStop(0.80, 'rgba(90,110,220,0)');
      ctx.fillStyle = cgr;
      ctx.beginPath();
      ctx.arc(cx, cy, cr, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }

    // hyperspace streaks
    if (f.hyper > 0) drawHyper(ctx, W, H, f.hyper);

    // final blackout
    if (f.black > 0.001) {
      ctx.save();
      ctx.globalAlpha = f.black;
      ctx.fillStyle = '#000';
      ctx.fillRect(0, 0, W, H);
      ctx.restore();
    }
  }

  function drawHyper(ctx, W, H, prog) {
    var cx = W / 2, cy = H / 2;
    var warp = Math.pow(prog, 2.55);
    var reach = Math.sqrt(W * W + H * H) * 0.62;

    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    ctx.lineCap = 'round';
    ctx.globalAlpha = Math.min(1, prog * 3.2);

    // gathering glow at the tunnel mouth
    var gA = Math.min(1, prog * 1.4) * (1 - Math.max(0, (prog - 0.78) / 0.22));
    if (gA > 0.01) {
      var gr = ctx.createRadialGradient(cx, cy, 0, cx, cy, reach * 0.5);
      gr.addColorStop(0, 'rgba(255,238,214,' + (0.5 * gA) + ')');
      gr.addColorStop(0.4, 'rgba(255,180,120,' + (0.16 * gA) + ')');
      gr.addColorStop(1, 'rgba(120,150,255,0)');
      ctx.fillStyle = gr;
      ctx.fillRect(0, 0, W, H);
    }

    var scale = Math.min(W, H) / 800;   // keep streak length proportional
    for (var i = 0; i < stars.length; i++) {
      var s = stars[i];
      var dx = Math.cos(s.a), dy = Math.sin(s.a);
      var r = s.r0 + warp * reach * (0.4 + s.spd);
      var len = (3 + warp * 300 * (0.35 + s.spd)) * scale;
      var al = Math.min(1, prog * 1.5) * Math.min(1, r / 90);
      ctx.strokeStyle = s.col + al + ')';
      ctx.lineWidth = (0.7 + warp * 2.4) * scale;
      ctx.beginPath();
      ctx.moveTo(cx + dx * r, cy + dy * r);
      ctx.lineTo(cx + dx * (r + len), cy + dy * (r + len));
      ctx.stroke();
    }
    ctx.restore();
  }

  /* ======================================================================
     INTERACTIVE CHARGE LAYER (the live hover effect, in-canvas)
     Drawn on top of the resting photo. Same geometry as render() so the
     hover state and the dive share one coordinate space — no seams.
     ====================================================================== */
  var CCOL = {
    warm:'rgba(255,222,180,', orange:'rgba(255,154,90,',
    teal:'rgba(64,224,205,',  blue:'rgba(86,150,235,',
    violet:'rgba(181,140,255,', red:'rgba(224,85,107,'
  };
  var chargeGeo = null, chargeR = -1;

  function buildCharge(cx, cy, R) {
    var edges = [];
    // 12 radial spokes (alternating long/short)
    for (var k = 0; k < 12; k++) {
      var ang = (k * 30) * Math.PI / 180, long = (k % 2 === 0);
      var r0 = R * 0.15, r1 = R * (long ? 0.98 : 0.66);
      edges.push({
        pts: [[cx + Math.cos(ang) * r0, cy + Math.sin(ang) * r0],
              [cx + Math.cos(ang) * r1, cy + Math.sin(ang) * r1]],
        col: long ? CCOL.blue : CCOL.teal, w: long ? 1.6 : 1.2,
        dash: [14, 26], speed: long ? 70 : 52
      });
    }
    function hexRing(rad, col, wid, spd) {
      var pts = [];
      for (var v = 0; v <= 6; v++) {
        var a = (-90 + v * 60) * Math.PI / 180;
        pts.push([cx + Math.cos(a) * rad, cy + Math.sin(a) * rad]);
      }
      edges.push({ pts: pts, col: col, w: wid, dash: [18, 30], speed: spd });
    }
    hexRing(R * 0.50, CCOL.teal, 1.7, 46);
    hexRing(R * 0.92, CCOL.blue, 1.5, 38);
    hexRing(R * 0.26, CCOL.warm, 1.4, 60);
    // three diagonal beams
    var diag = -28 * Math.PI / 180, nx = Math.cos(diag), ny = Math.sin(diag);
    var px = -ny, py = nx, L = R * 3.2;
    var offs = [-0.42, 0, 0.42], dcol = [CCOL.red, CCOL.warm, CCOL.violet];
    for (var d = 0; d < offs.length; d++) {
      var ox = cx + px * offs[d] * R, oy = cy + py * offs[d] * R;
      edges.push({
        pts: [[ox - nx * L, oy - ny * L], [ox + nx * L, oy + ny * L]],
        col: dcol[d], w: 1.3, dash: [10, 40], speed: 120
      });
    }
    edges.forEach(function (e) { e.mid = e.pts[Math.floor(e.pts.length / 2)] || e.pts[0]; });
    return edges;
  }

  // st = { energy 0..1, mx, my (px), t (seconds) }
  function renderCharge(ctx, W, H, st) {
    if (!st || st.energy <= 0.003) return;
    var cx = W / 2, cy = H / 2, box = H * 0.62, R = box * 0.494;
    var lw = Math.max(1, R / 280);                 // scale stroke to size
    if (!chargeGeo || chargeR !== R) { chargeGeo = buildCharge(cx, cy, R); chargeR = R; }
    var mx = st.mx == null ? cx : st.mx, my = st.my == null ? cy : st.my;
    var e = st.energy, t = st.t || 0;

    ctx.save();
    ctx.globalCompositeOperation = 'screen';
    ctx.lineCap = 'round';
    for (var i = 0; i < chargeGeo.length; i++) {
      var g = chargeGeo[i];
      var dx = mx - g.mid[0], dy = my - g.mid[1];
      var prox = Math.max(0, 1 - Math.sqrt(dx * dx + dy * dy) / (R * 1.25));
      var a = e * (0.10 + 0.62 * prox);
      if (a <= 0.003) continue;
      ctx.globalAlpha = a;
      ctx.strokeStyle = g.col + '1)';
      ctx.lineWidth = g.w * lw;
      ctx.shadowColor = g.col + '1)';
      ctx.shadowBlur = (5 + 16 * prox) * e * lw;
      ctx.setLineDash([g.dash[0] * lw, g.dash[1] * lw]);
      ctx.lineDashOffset = -(t * g.speed * (0.55 + prox)) * lw;
      ctx.beginPath();
      ctx.moveTo(g.pts[0][0], g.pts[0][1]);
      for (var p = 1; p < g.pts.length; p++) ctx.lineTo(g.pts[p][0], g.pts[p][1]);
      ctx.stroke();
    }
    // warm light pooled under the cursor
    ctx.setLineDash([]); ctx.shadowBlur = 0;
    var hr = R * 0.55;
    var grd = ctx.createRadialGradient(mx, my, 0, mx, my, hr);
    grd.addColorStop(0,    'rgba(255,244,224,' + (0.55 * e) + ')');
    grd.addColorStop(0.35, 'rgba(255,186,120,' + (0.20 * e) + ')');
    grd.addColorStop(1,    'rgba(255,186,120,0)');
    ctx.globalAlpha = 1;
    ctx.fillStyle = grd;
    ctx.beginPath(); ctx.arc(mx, my, hr, 0, Math.PI * 2); ctx.fill();
    ctx.restore();
  }

  global.PortalDive = {
    setImage: setImage,
    render: render,
    renderCharge: renderCharge,
    WEDGES: WEDGES
  };
})(typeof window !== 'undefined' ? window : this);
