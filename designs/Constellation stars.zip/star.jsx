// Gaseous Star — 8 movement variants, continuous mass scale, palette + border.
// Renders a translucent sphere whose gas layers (turbulence-masked colored
// gradients) animate according to data-movement on the root.

// ── Mass profile: continuous interpolation along [0..1] ─────────────────────
// Anchor points define key stages; we lerp between them.
const MASS_ANCHORS = [
  { t: 0.00, size: 86,  halo: 0.12, aura: 0.06, layerOp: [0.42, 0.30, 0.20, 0.12], coreR: 2.2, bloom: 0.78, sat: 0.80 },
  { t: 0.33, size: 122, halo: 0.30, aura: 0.18, layerOp: [0.62, 0.52, 0.42, 0.32], coreR: 3.6, bloom: 0.96, sat: 0.98 },
  { t: 0.66, size: 158, halo: 0.50, aura: 0.32, layerOp: [0.78, 0.70, 0.60, 0.50], coreR: 5.8, bloom: 1.18, sat: 1.15 },
  { t: 1.00, size: 190, halo: 0.72, aura: 0.46, layerOp: [0.92, 0.86, 0.78, 0.70], coreR: 8.4, bloom: 1.36, sat: 1.30 },
];

function lerp(a, b, t) { return a + (b - a) * t; }

function massProfile(mass) {
  // find segment
  const m = Math.max(0, Math.min(1, mass));
  let a = MASS_ANCHORS[0], b = MASS_ANCHORS[1];
  for (let i = 0; i < MASS_ANCHORS.length - 1; i++) {
    if (m >= MASS_ANCHORS[i].t && m <= MASS_ANCHORS[i + 1].t) {
      a = MASS_ANCHORS[i];
      b = MASS_ANCHORS[i + 1];
      break;
    }
  }
  const span = (b.t - a.t) || 1;
  const k = (m - a.t) / span;
  return {
    size: lerp(a.size, b.size, k),
    halo: lerp(a.halo, b.halo, k),
    aura: lerp(a.aura, b.aura, k),
    layerOp: a.layerOp.map((v, i) => lerp(v, b.layerOp[i], k)),
    coreR: lerp(a.coreR, b.coreR, k),
    bloom: lerp(a.bloom, b.bloom, k),
    sat: lerp(a.sat, b.sat, k),
  };
}

// Per-movement filter assignments and gradient layouts ─────────────────────
const MOVEMENT_PRESETS = {
  vortex:     { filters: ['wisp-A', 'wisp-B', 'wisp-A', 'wisp-B'], grad: 'default' },
  orbital:    { filters: ['wisp-C', 'wisp-A', 'wisp-C', 'wisp-A'], grad: 'banded' },
  convection: { filters: ['wisp-D', 'wisp-B', 'wisp-A', 'wisp-C'], grad: 'cells' },
  pulsar:     { filters: ['wisp-ripple', 'wisp-ripple', 'wisp-ripple', 'wisp-A'], grad: 'centered' },
  spiral:     { filters: ['wisp-streak', 'wisp-streak', 'wisp-streak', 'wisp-streak'], grad: 'spiral' },
  flare:      { filters: ['wisp-A', 'wisp-hot', 'wisp-hot', 'wisp-hot'], grad: 'cells' },
  binary:     { filters: ['wisp-bi', 'wisp-bi', 'wisp-A', 'wisp-B'], grad: 'bipolar' },
  drift:      { filters: ['wisp-D', 'wisp-D', 'wisp-A', 'wisp-A'], grad: 'cells' },
};

const GRAD_LAYOUTS = {
  default: [
    { cx: 0.40, cy: 0.36, r: 0.62 },
    { cx: 0.62, cy: 0.58, r: 0.55 },
    { cx: 0.34, cy: 0.66, r: 0.60 },
    { cx: 0.66, cy: 0.30, r: 0.50 },
  ],
  banded: [
    { cx: 0.50, cy: 0.30, r: 0.55 },
    { cx: 0.50, cy: 0.50, r: 0.55 },
    { cx: 0.50, cy: 0.70, r: 0.55 },
    { cx: 0.50, cy: 0.50, r: 0.65 },
  ],
  cells: [
    { cx: 0.30, cy: 0.30, r: 0.48 },
    { cx: 0.70, cy: 0.32, r: 0.46 },
    { cx: 0.30, cy: 0.70, r: 0.46 },
    { cx: 0.70, cy: 0.70, r: 0.48 },
  ],
  centered: [
    { cx: 0.50, cy: 0.50, r: 0.55 },
    { cx: 0.50, cy: 0.50, r: 0.55 },
    { cx: 0.50, cy: 0.50, r: 0.55 },
    { cx: 0.50, cy: 0.50, r: 0.55 },
  ],
  spiral: [
    { cx: 0.35, cy: 0.50, r: 0.60 },
    { cx: 0.65, cy: 0.50, r: 0.55 },
    { cx: 0.50, cy: 0.35, r: 0.50 },
    { cx: 0.50, cy: 0.65, r: 0.45 },
  ],
  bipolar: [
    { cx: 0.30, cy: 0.50, r: 0.40 },
    { cx: 0.70, cy: 0.50, r: 0.40 },
    { cx: 0.50, cy: 0.50, r: 0.55 },
    { cx: 0.50, cy: 0.50, r: 0.60 },
  ],
};

// Movement-specific layer transforms (e.g. orbital tilt is done via CSS; here for spiral we may skew)
function Star({ movement, mass, palette, border = 'soft', idHint = '' }) {
  const profile = massProfile(mass);
  const preset = MOVEMENT_PRESETS[movement] || MOVEMENT_PRESETS.vortex;
  const gradPositions = GRAD_LAYOUTS[preset.grad] || GRAD_LAYOUTS.default;
  const uid = React.useMemo(() => idHint + '-' + Math.random().toString(36).slice(2, 7), [idHint, movement]);
  const colors = palette.colors;
  const haloColor = palette.halo || colors[0];

  const starStyle = {
    '--size': profile.size + 'px',
    '--halo-color': haloColor,
    '--halo-opacity': profile.halo,
    '--aura-opacity': profile.aura,
    filter: `brightness(${profile.bloom.toFixed(3)}) saturate(${profile.sat.toFixed(3)})`,
  };

  const isBinary = movement === 'binary';

  return (
    <div className="star" data-movement={movement} style={starStyle}>
      <div className="halo"></div>
      <div className="aura"></div>
      <div className="sphere">
        <svg viewBox="0 0 200 200" preserveAspectRatio="xMidYMid meet">
          <defs>
            <clipPath id={`clip-${uid}`}>
              <circle cx="100" cy="100" r="94" />
            </clipPath>
            {colors.map((c, i) => {
              const g = gradPositions[i] || gradPositions[0];
              return (
                <radialGradient
                  key={i}
                  id={`grad-${uid}-${i}`}
                  cx={g.cx} cy={g.cy} r={g.r}
                  fx={g.cx} fy={g.cy}
                >
                  <stop offset="0%" stopColor={c} stopOpacity="1" />
                  <stop offset="55%" stopColor={c} stopOpacity="0.85" />
                  <stop offset="100%" stopColor={c} stopOpacity="0.20" />
                </radialGradient>
              );
            })}
            {/* Core gradient — white-hot center fading to palette color */}
            <radialGradient id={`core-${uid}`} cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="white" stopOpacity="1" />
              <stop offset="30%" stopColor={colors[0]} stopOpacity="0.95" />
              <stop offset="70%" stopColor={colors[1] || colors[0]} stopOpacity="0.4" />
              <stop offset="100%" stopColor={colors[0]} stopOpacity="0" />
            </radialGradient>
            <radialGradient id={`pinpoint-${uid}`} cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="white" stopOpacity="1" />
              <stop offset="60%" stopColor="white" stopOpacity="0.6" />
              <stop offset="100%" stopColor="white" stopOpacity="0" />
            </radialGradient>
          </defs>

          {/* Body inside spherical clip */}
          <g clipPath={`url(#clip-${uid})`}>
            <circle cx="100" cy="100" r="94" fill="url(#sphere-deep)" />

            {/* Gas layers */}
            {[0, 1, 2, 3].map((i) => (
              <g key={i} className={`gas-layer gas-${i + 1}`}>
                <g
                  className="gas-anim"
                  style={{ '--lo': profile.layerOp[i] }}
                >
                  <circle
                    cx="100" cy="100" r="94"
                    fill={`url(#grad-${uid}-${i})`}
                    filter={`url(#${preset.filters[i]})`}
                    opacity={profile.layerOp[i]}
                    style={{ mixBlendMode: 'screen' }}
                  />
                </g>
              </g>
            ))}

            {/* Sphere shading */}
            <circle cx="100" cy="100" r="94" fill="url(#sphere-shade)" />
            <circle cx="100" cy="100" r="94" fill="url(#sphere-light)" />

            {/* Core — single, or binary twin */}
            {isBinary ? (
              <>
                <g className="binary-orbit-a">
                  <g style={{ transform: 'translate(-22px, 0)' }}>
                    <circle cx="100" cy="100" r={profile.coreR * 2.4} fill={`url(#core-${uid})`} opacity="0.85" style={{ mixBlendMode: 'screen' }} />
                    <circle cx="100" cy="100" r={profile.coreR * 1.1} fill={`url(#pinpoint-${uid})`} style={{ mixBlendMode: 'screen' }} />
                    <circle cx="100" cy="100" r={profile.coreR * 0.45} fill="white" opacity="0.95" />
                  </g>
                </g>
                <g className="binary-orbit-b">
                  <g style={{ transform: 'translate(-22px, 0)' }}>
                    <circle cx="100" cy="100" r={profile.coreR * 2.2} fill={`url(#core-${uid})`} opacity="0.80" style={{ mixBlendMode: 'screen' }} />
                    <circle cx="100" cy="100" r={profile.coreR * 1.0} fill={`url(#pinpoint-${uid})`} style={{ mixBlendMode: 'screen' }} />
                    <circle cx="100" cy="100" r={profile.coreR * 0.40} fill="white" opacity="0.95" />
                  </g>
                </g>
              </>
            ) : (
              <g className="core-glow">
                <circle cx="100" cy="100" r={profile.coreR * 3.2} fill={`url(#core-${uid})`} opacity="0.85" style={{ mixBlendMode: 'screen' }} />
                <circle cx="100" cy="100" r={profile.coreR * 1.6} fill={`url(#pinpoint-${uid})`} style={{ mixBlendMode: 'screen' }} />
                <circle cx="100" cy="100" r={profile.coreR * 0.5} fill="white" opacity="0.95" />
              </g>
            )}
          </g>

          {/* Rim treatment — "border" is where the star ends and starfield begins */}
          {border === 'soft' && (
            <circle cx="100" cy="100" r="94" fill="url(#rim-glow)" />
          )}
          {border === 'crisp' && (
            <>
              <circle cx="100" cy="100" r="94" fill="url(#rim-glow)" opacity="0.6" />
              <circle cx="100" cy="100" r="94" fill="none" stroke={haloColor} strokeWidth="1" opacity="0.95" />
            </>
          )}
          {border === 'halo' && (
            <>
              <circle cx="100" cy="100" r="94" fill="url(#rim-glow)" />
              <circle cx="100" cy="100" r="94" fill="none" stroke={haloColor} strokeWidth="0.8" opacity="0.9" />
              <circle cx="100" cy="100" r="98" fill="none" stroke={haloColor} strokeWidth="0.5" opacity="0.55" />
              <circle cx="100" cy="100" r="102" fill="none" stroke={haloColor} strokeWidth="0.3" opacity="0.30" />
            </>
          )}
          {border === 'dashed' && (
            <>
              <circle cx="100" cy="100" r="94" fill="url(#rim-glow)" opacity="0.55" />
              <circle
                className="dashed-ring"
                cx="100" cy="100" r="95.5"
                fill="none"
                stroke={haloColor}
                strokeWidth="0.9"
                strokeDasharray="3 2.5"
                opacity="0.9"
              />
            </>
          )}
          {border === 'corona' && (
            <>
              <circle cx="100" cy="100" r="94" fill="url(#rim-glow)" />
              <g className="corona-ring">
                <circle
                  cx="100" cy="100" r="96"
                  fill="none"
                  stroke="white"
                  strokeWidth="2.2"
                  filter="url(#corona-fx)"
                  opacity="0.95"
                />
                <circle
                  cx="100" cy="100" r="99"
                  fill="none"
                  stroke={haloColor}
                  strokeWidth="3"
                  filter="url(#corona-fx)"
                  opacity="0.7"
                />
              </g>
              <circle cx="100" cy="100" r="94" fill="none" stroke={haloColor} strokeWidth="0.4" opacity="0.6" />
            </>
          )}
        </svg>
      </div>
    </div>
  );
}

window.Star = Star;
window.massProfile = massProfile;
