// App — 8 specimens in a 4×2 grid sharing mass + palette + border + speed.
// Bottom dock: mass · speed · spectrum · border (rim).

const MOVEMENTS = [
  { id: 'vortex',     code: 'M·01', name: 'Vortex',     pulse: 'Cyclonic Shear',     desc: 'Concentric shear; gas layers spin one axis at varying rates.' },
  { id: 'orbital',    code: 'M·02', name: 'Orbital',    pulse: 'Banded Rotation',    desc: 'Tilted belts revolve on inclined planes — a gas giant.' },
  { id: 'convection', code: 'M·03', name: 'Convection', pulse: 'Turbulent Pulse',    desc: 'Cells dilate and counter-drift, never quite in sync.' },
  { id: 'pulsar',     code: 'M·04', name: 'Pulsar',     pulse: 'Radial Heartbeat',   desc: 'Rings expand outward in rhythmic waves from the core.' },
  { id: 'spiral',     code: 'M·05', name: 'Spiral',     pulse: 'Differential Winding', desc: 'Inner layers race ahead, winding arms outward.' },
  { id: 'flare',      code: 'M·06', name: 'Flare',      pulse: 'Surface Eruption',   desc: 'Quiet surface punctuated by bright burst events.' },
  { id: 'binary',     code: 'M·07', name: 'Binary',     pulse: 'Twin Locked Cores',  desc: 'Two fusion cores orbit each other within shared gas.' },
  { id: 'drift',      code: 'M·08', name: 'Drift',      pulse: 'Asymmetric Float',   desc: 'Slow, untethered translation — wandering layers.' },
];

const MASS_PHASES = [
  { t: 0.000, name: 'Protostar',     short: 'I'   },
  { t: 0.333, name: 'Main Sequence', short: 'II'  },
  { t: 0.666, name: 'Giant',         short: 'III' },
  { t: 1.000, name: 'Supergiant',    short: 'IV'  },
];

function phaseForMass(m) {
  let p = MASS_PHASES[0];
  for (const ph of MASS_PHASES) if (m >= ph.t) p = ph;
  return p;
}

// 8 palettes — 4 multi-hue (dynamic), 4 monochromatic
const PALETTES = [
  { id: 'nebula',   name: 'Nebula',   colors: ['#7eb6ff', '#a47cff', '#ff8b65', '#ffb097'], halo: '#9b8aff', isMulti: true },
  { id: 'aurora',   name: 'Aurora',   colors: ['#5bf2c0', '#5beaff', '#a47cff', '#7eb6ff'], halo: '#5cf0d0', isMulti: true },
  { id: 'sunset',   name: 'Sunset',   colors: ['#ffd370', '#ff7a52', '#ff5acf', '#a47cff'], halo: '#ff7a8c', isMulti: true },
  { id: 'twilight', name: 'Twilight', colors: ['#5d8bff', '#a47cff', '#ff7ab8', '#ffd370'], halo: '#9b8aff', isMulti: true },
  { id: 'solar',    name: 'Solar',    colors: ['#ffd370', '#ffa549', '#ff7140', '#ffe6a8'], halo: '#ffb558' },
  { id: 'cobalt',   name: 'Cobalt',   colors: ['#79c5ff', '#5d8bff', '#7e6cff', '#b5d3ff'], halo: '#6a9eff' },
  { id: 'ember',    name: 'Ember',    colors: ['#ff7a52', '#ff4a4a', '#cc2a4a', '#ffa97a'], halo: '#ff5a4a' },
  { id: 'emerald',  name: 'Emerald',  colors: ['#5bf2a6', '#4ee6c8', '#5beaff', '#a8ffd6'], halo: '#5cf0c0' },
];

// Rim border styles — where the star ends and starfield begins
const BORDERS = [
  { id: 'soft',   name: 'Soft'   },
  { id: 'crisp',  name: 'Crisp'  },
  { id: 'halo',   name: 'Halo'   },
  { id: 'dashed', name: 'Dashed' },
  { id: 'corona', name: 'Corona' },
];

const DEFAULT_TWEAKS = /*EDITMODE-BEGIN*/{
  "starDensity": 1.0
}/*EDITMODE-END*/;

// Border preview glyphs (mini star-rim hints) ─────────────────────────────
function BorderGlyph({ kind }) {
  const stroke = 'currentColor';
  switch (kind) {
    case 'soft':
      return (
        <svg viewBox="0 0 20 20" fill="none">
          <defs>
            <radialGradient id={`gly-soft-${stroke}`} cx="50%" cy="50%" r="50%">
              <stop offset="60%" stopColor={stroke} stopOpacity="0.55"/>
              <stop offset="100%" stopColor={stroke} stopOpacity="0"/>
            </radialGradient>
          </defs>
          <circle cx="10" cy="10" r="8" fill={`url(#gly-soft-${stroke})`}/>
        </svg>
      );
    case 'crisp':
      return (
        <svg viewBox="0 0 20 20" fill="none">
          <circle cx="10" cy="10" r="6" stroke={stroke} strokeWidth="1.1"/>
        </svg>
      );
    case 'halo':
      return (
        <svg viewBox="0 0 20 20" fill="none" stroke={stroke}>
          <circle cx="10" cy="10" r="5" strokeWidth="1"/>
          <circle cx="10" cy="10" r="7.5" strokeWidth="0.55" opacity="0.7"/>
          <circle cx="10" cy="10" r="9.4" strokeWidth="0.35" opacity="0.4"/>
        </svg>
      );
    case 'dashed':
      return (
        <svg viewBox="0 0 20 20" fill="none">
          <circle cx="10" cy="10" r="6" stroke={stroke} strokeWidth="1" strokeDasharray="2 1.6"/>
        </svg>
      );
    case 'corona':
      return (
        <svg viewBox="0 0 20 20" fill="none" stroke={stroke}>
          <circle cx="10" cy="10" r="5" strokeWidth="0.9"/>
          {[0, 45, 90, 135, 180, 225, 270, 315].map((a, i) => {
            const r1 = a % 90 === 0 ? 6.4 : 6.0;
            const r2 = a % 90 === 0 ? 8.6 : 7.8;
            const rad = (a - 90) * Math.PI / 180;
            return <line key={i}
              x1={10 + Math.cos(rad) * r1} y1={10 + Math.sin(rad) * r1}
              x2={10 + Math.cos(rad) * r2} y2={10 + Math.sin(rad) * r2}
              strokeWidth="0.7" opacity="0.85"
            />;
          })}
        </svg>
      );
    default: return null;
  }
}

// Specimen card ───────────────────────────────────────────────────────────
function Specimen({ movement, mass, palette, speed, border }) {
  return (
    <div
      className="specimen"
      data-screen-label={`Specimen ${movement.code} ${movement.name}`}
    >
      <div className="specimen-cap">
        <div className="specimen-id">{movement.code} · {movement.pulse}</div>
        <div className="specimen-name">{movement.name}</div>
      </div>
      <div className="specimen-stage" style={{ '--spd': speed }}>
        <window.Star
          movement={movement.id}
          mass={mass}
          palette={palette}
          border={border}
          idHint={movement.id + '-' + palette.id + '-' + border}
        />
      </div>
    </div>
  );
}

// Controls dock ───────────────────────────────────────────────────────────
function Controls({ mass, setMass, speed, setSpeed, paletteId, setPaletteId, border, setBorder }) {
  const phase = phaseForMass(mass);
  const massPct = Math.round(mass * 100);
  // Speed: 0.25..3, default 1. Map to 0..1 for slider visual fill
  const speedPct = Math.round(((speed - 0.25) / (3 - 0.25)) * 100);
  return (
    <div className="controls" role="toolbar" aria-label="Star controls">
      <div className="ctrl-group">
        <div className="ctrl-stack">
          <span className="ctrl-label">Mass</span>
          <span className="phase-inline">{phase.name}</span>
        </div>
        <div className="mass-slider-wrap">
          <input
            type="range"
            className="mass-slider"
            min="0" max="1" step="0.001"
            value={mass}
            onChange={(e) => setMass(parseFloat(e.target.value))}
            style={{ '--massPct': massPct + '%' }}
            aria-label="Stellar mass"
          />
          <div className="mass-ticks">
            {MASS_PHASES.map((p) => {
              const dist = Math.abs(mass - p.t);
              return (
                <span key={p.short} className={dist < 0.10 ? 'near' : ''} title={p.name}>
                  {p.short}
                </span>
              );
            })}
          </div>
        </div>
      </div>

      <div className="ctrl-divider"></div>

      <div className="ctrl-group">
        <div className="ctrl-stack">
          <span className="ctrl-label">Speed</span>
          <span className="phase-inline">{speed.toFixed(2)}×</span>
        </div>
        <div className="mass-slider-wrap speed">
          <input
            type="range"
            className="mass-slider"
            min="0.25" max="3" step="0.05"
            value={speed}
            onChange={(e) => setSpeed(parseFloat(e.target.value))}
            style={{ '--massPct': speedPct + '%' }}
            aria-label="Rotation speed"
          />
          <div className="mass-ticks">
            <span className={Math.abs(speed - 0.5) < 0.2 ? 'near' : ''}>·5</span>
            <span className={Math.abs(speed - 1) < 0.2 ? 'near' : ''}>1×</span>
            <span className={Math.abs(speed - 2) < 0.3 ? 'near' : ''}>2×</span>
            <span className={speed > 2.5 ? 'near' : ''}>3×</span>
          </div>
        </div>
      </div>

      <div className="ctrl-divider"></div>

      <div className="ctrl-group">
        <span className="ctrl-label">Spectrum</span>
        <div className="palette-grid">
          {PALETTES.map((p) => (
            <button
              key={p.id}
              className={'swatch' + (paletteId === p.id ? ' active' : '')}
              onClick={() => setPaletteId(p.id)}
              title={p.name + (p.isMulti ? ' (multi-color)' : '')}
              aria-label={p.name}
            >
              <span
                className="swatch-fill"
                style={
                  p.isMulti
                    ? { background: `conic-gradient(from 220deg, ${p.colors[0]} 0deg, ${p.colors[1]} 90deg, ${p.colors[2]} 180deg, ${p.colors[3]} 270deg, ${p.colors[0]} 360deg)` }
                    : { background: `radial-gradient(circle at 35% 30%, ${p.colors[0]} 0%, ${p.colors[1]} 55%, ${p.colors[2]} 100%)` }
                }
              ></span>
            </button>
          ))}
        </div>
      </div>

      <div className="ctrl-divider"></div>

      <div className="ctrl-group">
        <span className="ctrl-label">Edge</span>
        <div className="border-options">
          {BORDERS.map((b) => (
            <button
              key={b.id}
              className={'border-btn' + (border === b.id ? ' active' : '')}
              onClick={() => setBorder(b.id)}
              title={b.name}
              aria-label={b.name}
            >
              <BorderGlyph kind={b.id} />
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

// App ─────────────────────────────────────────────────────────────────────
function App() {
  const [mass, setMass] = React.useState(0.45);
  const [speed, setSpeed] = React.useState(1.0);
  const [paletteId, setPaletteId] = React.useState('nebula');
  const [border, setBorder] = React.useState('soft');
  const [tweaks, setTweak] = window.useTweaks(DEFAULT_TWEAKS);

  const palette = PALETTES.find((p) => p.id === paletteId) || PALETTES[0];

  // Keyboard: ←/→ palettes, ↑/↓ mass, B cycles border, [/] speed
  React.useEffect(() => {
    const onKey = (e) => {
      if (e.target.matches && e.target.matches('input, textarea')) return;
      if (e.key === 'ArrowRight') {
        const i = PALETTES.findIndex((p) => p.id === paletteId);
        setPaletteId(PALETTES[(i + 1) % PALETTES.length].id);
      } else if (e.key === 'ArrowLeft') {
        const i = PALETTES.findIndex((p) => p.id === paletteId);
        setPaletteId(PALETTES[(i - 1 + PALETTES.length) % PALETTES.length].id);
      } else if (e.key === 'ArrowUp') {
        setMass((m) => Math.min(1, m + 0.05));
      } else if (e.key === 'ArrowDown') {
        setMass((m) => Math.max(0, m - 0.05));
      } else if (e.key === 'b' || e.key === 'B') {
        const i = BORDERS.findIndex((b) => b.id === border);
        setBorder(BORDERS[(i + 1) % BORDERS.length].id);
      } else if (e.key === ']') {
        setSpeed((s) => Math.min(3, s + 0.1));
      } else if (e.key === '[') {
        setSpeed((s) => Math.max(0.25, s - 0.1));
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [paletteId, border]);

  const { TweaksPanel, TweakSection, TweakSlider } = window;

  return (
    <div className="app">
      <header className="header">
        <div className="brandmark">
          <span className="mark-diamond"></span>
          <span className="brand-title">Gaseous · Star · Studies</span>
        </div>
        <div className="header-meta">
          <div className="live"><span className="live-dot"></span>Observatory · Live</div>
          <div>Catalog · GS-{paletteId.slice(0, 3).toUpperCase()}-{('00' + Math.round(mass * 99)).slice(-2)}</div>
        </div>
      </header>

      <div className="stage">
        {MOVEMENTS.map((m) => (
          <Specimen
            key={m.id}
            movement={m}
            mass={mass}
            palette={palette}
            speed={speed}
            border={border}
          />
        ))}
      </div>

      <Controls
        mass={mass}
        setMass={setMass}
        speed={speed}
        setSpeed={setSpeed}
        paletteId={paletteId}
        setPaletteId={setPaletteId}
        border={border}
        setBorder={setBorder}
      />

      <TweaksPanel title="Tweaks">
        <TweakSection title="Field">
          <TweakSlider
            label="Star field density"
            value={tweaks.starDensity}
            min={0.2} max={2} step={0.1}
            onChange={(v) => {
              setTweak('starDensity', v);
              if (window.__regenStarfield) window.__regenStarfield(v);
            }}
            format={(v) => v.toFixed(1) + '×'}
          />
        </TweakSection>
      </TweaksPanel>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);

// Starfield regen hook
window.__regenStarfield = function (factor) {
  const root = document.getElementById('starfield');
  if (!root) return;
  const N = Math.round(220 * factor);
  let html = '';
  for (let i = 0; i < N; i++) {
    const x = Math.random() * 100;
    const y = Math.random() * 100;
    const r = Math.random();
    const size = r < 0.78 ? 1 : r < 0.95 ? 2 : 3;
    const opacity = (0.18 + Math.random() * 0.72).toFixed(2);
    const dur = (3 + Math.random() * 8).toFixed(1);
    const delay = (Math.random() * -6).toFixed(1);
    const blur = size === 3 ? 'filter: blur(0.4px);' : '';
    html += `<span class="star-dot" style="left:${x}%;top:${y}%;width:${size}px;height:${size}px;--o-base:${opacity};opacity:${opacity};${blur}animation:twinkle ${dur}s ease-in-out ${delay}s infinite"></span>`;
  }
  root.innerHTML = html;
};
